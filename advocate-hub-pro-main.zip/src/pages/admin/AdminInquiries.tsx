import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Search, 
  Filter, 
  Eye, 
  Clock, 
  CheckCircle, 
  AlertCircle,
  ChevronDown,
  X
} from 'lucide-react';

const mockInquiries = [
  { 
    id: 'INQ-001', 
    name: 'Rajesh Kumar', 
    email: 'rajesh@email.com',
    mobile: '+91 98765 43210',
    city: 'Delhi',
    category: 'Criminal Law', 
    status: 'New', 
    date: '2024-01-20',
    amount: 499,
    description: 'I have been falsely accused in a cheating case. Need legal advice on how to proceed with anticipatory bail.'
  },
  { 
    id: 'INQ-002', 
    name: 'Priya Sharma', 
    email: 'priya@email.com',
    mobile: '+91 98765 43211',
    city: 'Gurgaon',
    category: 'Family Law', 
    status: 'In Progress', 
    date: '2024-01-19',
    amount: 499,
    description: 'Seeking divorce due to incompatibility. Need guidance on mutual consent divorce process and maintenance.'
  },
  { 
    id: 'INQ-003', 
    name: 'Amit Singh', 
    email: 'amit@email.com',
    mobile: '+91 98765 43212',
    city: 'Noida',
    category: 'Property Law', 
    status: 'Closed', 
    date: '2024-01-18',
    amount: 499,
    description: 'Property dispute with siblings over ancestral property. Need help with partition suit.'
  },
  { 
    id: 'INQ-004', 
    name: 'Sneha Patel', 
    email: 'sneha@email.com',
    mobile: '+91 98765 43213',
    city: 'Mumbai',
    category: 'Corporate Law', 
    status: 'New', 
    date: '2024-01-18',
    amount: 499,
    description: 'Starting a new tech startup. Need legal assistance with company registration and shareholder agreements.'
  },
  { 
    id: 'INQ-005', 
    name: 'Vikram Rao', 
    email: 'vikram@email.com',
    mobile: '+91 98765 43214',
    city: 'Bangalore',
    category: 'Civil Litigation', 
    status: 'In Progress', 
    date: '2024-01-17',
    amount: 499,
    description: 'Money recovery case against a business partner who defaulted on payment of Rs 15 lakhs.'
  },
];

const statusConfig = {
  'New': { icon: AlertCircle, className: 'badge-new' },
  'In Progress': { icon: Clock, className: 'badge-progress' },
  'Closed': { icon: CheckCircle, className: 'badge-closed' },
};

const categories = ['All', 'Criminal Law', 'Civil Litigation', 'Family Law', 'Property Law', 'Corporate Law', 'Consumer Law'];
const statuses = ['All', 'New', 'In Progress', 'Closed'];

const AdminInquiries = () => {
  const [searchQuery, setSearchQuery] = useState('');
  const [selectedCategory, setSelectedCategory] = useState('All');
  const [selectedStatus, setSelectedStatus] = useState('All');
  const [selectedInquiry, setSelectedInquiry] = useState<typeof mockInquiries[0] | null>(null);

  const filteredInquiries = mockInquiries.filter(inquiry => {
    const matchesSearch = inquiry.name.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          inquiry.id.toLowerCase().includes(searchQuery.toLowerCase()) ||
                          inquiry.email.toLowerCase().includes(searchQuery.toLowerCase());
    const matchesCategory = selectedCategory === 'All' || inquiry.category === selectedCategory;
    const matchesStatus = selectedStatus === 'All' || inquiry.status === selectedStatus;
    return matchesSearch && matchesCategory && matchesStatus;
  });

  return (
    <div className="space-y-6">
      {/* Filters */}
      <div className="admin-card">
        <div className="flex flex-col lg:flex-row gap-4">
          {/* Search */}
          <div className="relative flex-1">
            <Search className="absolute left-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground" />
            <input
              type="text"
              value={searchQuery}
              onChange={(e) => setSearchQuery(e.target.value)}
              placeholder="Search by name, ID, or email..."
              className="form-input pl-10"
            />
          </div>

          {/* Category Filter */}
          <div className="relative">
            <select
              value={selectedCategory}
              onChange={(e) => setSelectedCategory(e.target.value)}
              className="form-input appearance-none pr-10 min-w-[180px]"
            >
              {categories.map((cat) => (
                <option key={cat} value={cat}>{cat === 'All' ? 'All Categories' : cat}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" />
          </div>

          {/* Status Filter */}
          <div className="relative">
            <select
              value={selectedStatus}
              onChange={(e) => setSelectedStatus(e.target.value)}
              className="form-input appearance-none pr-10 min-w-[150px]"
            >
              {statuses.map((status) => (
                <option key={status} value={status}>{status === 'All' ? 'All Status' : status}</option>
              ))}
            </select>
            <ChevronDown className="absolute right-3 top-1/2 -translate-y-1/2 w-5 h-5 text-muted-foreground pointer-events-none" />
          </div>
        </div>
      </div>

      {/* Consultations Table */}
      <div className="admin-card overflow-hidden">
        <div className="overflow-x-auto">
          <table className="w-full">
            <thead>
              <tr className="table-header">
                <th className="text-left py-3 px-4 rounded-l-lg">ID</th>
                <th className="text-left py-3 px-4">Client</th>
                <th className="text-left py-3 px-4">Category</th>
                <th className="text-left py-3 px-4">Date</th>
                <th className="text-left py-3 px-4">Status</th>
                <th className="text-right py-3 px-4">Amount</th>
                <th className="text-right py-3 px-4 rounded-r-lg">Actions</th>
              </tr>
            </thead>
            <tbody>
              {filteredInquiries.map((inquiry) => (
                <tr key={inquiry.id} className="table-row">
                  <td className="py-4 px-4">
                    <span className="font-mono text-sm text-muted-foreground">
                      {inquiry.id}
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <div>
                      <span className="font-medium text-foreground block">{inquiry.name}</span>
                      <span className="text-sm text-muted-foreground">{inquiry.email}</span>
                    </div>
                  </td>
                  <td className="py-4 px-4">
                    <span className="text-muted-foreground">{inquiry.category}</span>
                  </td>
                  <td className="py-4 px-4">
                    <span className="text-muted-foreground">
                      {new Date(inquiry.date).toLocaleDateString('en-IN', {
                        day: 'numeric',
                        month: 'short',
                        year: 'numeric'
                      })}
                    </span>
                  </td>
                  <td className="py-4 px-4">
                    <span className={statusConfig[inquiry.status as keyof typeof statusConfig].className}>
                      {inquiry.status}
                    </span>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <span className="font-medium text-foreground">₹{inquiry.amount}</span>
                  </td>
                  <td className="py-4 px-4 text-right">
                    <Button
                      variant="ghost"
                      size="sm"
                      onClick={() => setSelectedInquiry(inquiry)}
                      className="text-accent hover:text-accent"
                    >
                      <Eye className="w-4 h-4 mr-1" />
                      View
                    </Button>
                  </td>
                </tr>
              ))}
            </tbody>
          </table>
        </div>

        {filteredInquiries.length === 0 && (
          <div className="text-center py-12">
            <p className="text-muted-foreground">No consultations found matching your criteria.</p>
          </div>
        )}
      </div>

      {/* Detail Modal */}
      {selectedInquiry && (
        <div className="fixed inset-0 z-50 flex items-center justify-center p-4">
          <div 
            className="absolute inset-0 bg-black/50" 
            onClick={() => setSelectedInquiry(null)}
          />
          <div className="relative bg-card rounded-xl shadow-xl max-w-2xl w-full max-h-[90vh] overflow-y-auto">
            <div className="sticky top-0 bg-card border-b border-border p-6 flex items-center justify-between">
              <div>
                <h2 className="font-display text-xl font-semibold text-foreground">
                   Consultation Details
                </h2>
                <p className="text-sm text-muted-foreground">{selectedInquiry.id}</p>
              </div>
              <button 
                onClick={() => setSelectedInquiry(null)}
                className="p-2 hover:bg-muted rounded-lg"
              >
                <X className="w-5 h-5" />
              </button>
            </div>

            <div className="p-6 space-y-6">
              {/* Status & Category */}
              <div className="flex items-center gap-4">
                <span className={statusConfig[selectedInquiry.status as keyof typeof statusConfig].className}>
                  {selectedInquiry.status}
                </span>
                <span className="px-3 py-1 bg-muted text-muted-foreground rounded-full text-xs font-medium">
                  {selectedInquiry.category}
                </span>
              </div>

              {/* Client Info */}
              <div className="grid sm:grid-cols-2 gap-4">
                <div>
                  <label className="text-sm text-muted-foreground">Full Name</label>
                  <p className="font-medium text-foreground">{selectedInquiry.name}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">Mobile</label>
                  <p className="font-medium text-foreground">{selectedInquiry.mobile}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">Email</label>
                  <p className="font-medium text-foreground">{selectedInquiry.email}</p>
                </div>
                <div>
                  <label className="text-sm text-muted-foreground">City</label>
                  <p className="font-medium text-foreground">{selectedInquiry.city}</p>
                </div>
              </div>

              {/* Description */}
              <div>
                <label className="text-sm text-muted-foreground">Case Description</label>
                <p className="mt-2 p-4 bg-muted rounded-lg text-foreground">
                  {selectedInquiry.description}
                </p>
              </div>

              {/* Payment Info */}
              <div className="p-4 bg-green-50 border border-green-200 rounded-lg">
                <div className="flex items-center justify-between">
                  <div>
                    <p className="text-sm text-green-600">Payment Received</p>
                    <p className="font-semibold text-green-800">₹{selectedInquiry.amount}</p>
                  </div>
                  <p className="text-sm text-green-600">
                    {new Date(selectedInquiry.date).toLocaleDateString('en-IN', {
                      day: 'numeric',
                      month: 'long',
                      year: 'numeric'
                    })}
                  </p>
                </div>
              </div>

              {/* Internal Notes */}
              <div>
                <label className="text-sm text-muted-foreground">Internal Notes</label>
                <textarea
                  className="form-input mt-2 min-h-[100px]"
                  placeholder="Add internal notes about this consultation..."
                />
              </div>

              {/* Actions */}
              <div className="flex gap-4">
                <Button className="btn-gold flex-1">
                  Update Status
                </Button>
                <Button variant="outline" className="flex-1">
                  Assign to Staff
                </Button>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
};

export default AdminInquiries;
