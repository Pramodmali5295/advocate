// Firebase configuration for Advocate Hub Pro
import { initializeApp } from 'firebase/app';
import { getFirestore } from 'firebase/firestore';
import { getAnalytics } from 'firebase/analytics';

const firebaseConfig = {
  apiKey: 'AIzaSyDJWkHxXU3Y3VJdYmVRJll50_f6yX0QUf8',
  authDomain: 'advocate-81126.firebaseapp.com',
  projectId: 'advocate-81126',
  storageBucket: 'advocate-81126.firebasestorage.app',
  messagingSenderId: '586879889154',
  appId: '1:586879889154:web:9d94ba44adc7b653fd5c1b',
  measurementId: 'G-W7QT689MEZ',
};

// Initialize Firebase app
export const app = initializeApp(firebaseConfig);

// Firestore database instance — used across the project
export const db = getFirestore(app);

// Analytics (only in browser environments)
export const analytics = typeof window !== 'undefined' ? getAnalytics(app) : null;
