import { useState, useEffect } from 'react';
import { Link, useLocation } from 'react-router-dom';
import { Menu, X, Phone, Scale } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { cn } from '@/lib/utils';
import { useContent } from '@/context/ContentContext';
import { useTranslation } from 'react-i18next';
import LanguageToggle from '@/components/ui/LanguageToggle';
import { useLanguage } from '@/context/LanguageContext';

const navLinks = [
  { name: 'navigation.home', path: '/' },
  { name: 'navigation.about', path: '/about' },
  { name: 'navigation.practiceAreas', path: '/practice-areas' },
  { name: 'navigation.testimonials', path: '/testimonials' },
  { name: 'navigation.knowledgeBase', path: '/knowledge' },
  { name: 'navigation.contact', path: '/contact' },
];

export const Header = () => {
  const { t } = useTranslation();
  const { content } = useContent();
  const { settings } = content;
  const [isScrolled, setIsScrolled] = useState(false);
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const { isMarathi } = useLanguage();
  const location = useLocation();

  useEffect(() => {
    const handleScroll = () => {
      setIsScrolled(window.scrollY > 20);
    };
    window.addEventListener('scroll', handleScroll);
    return () => window.removeEventListener('scroll', handleScroll);
  }, []);

  const isActive = (path: string) => location.pathname === path;

  // Handle scroll lock when mobile menu is open
  useEffect(() => {
    if (isMobileMenuOpen) {
      document.body.style.overflow = 'hidden';
    } else {
      document.body.style.overflow = 'unset';
    }
    return () => {
      document.body.style.overflow = 'unset';
    };
  }, [isMobileMenuOpen]);

  // Close mobile menu when shifting orientation or window size
  useEffect(() => {
    const handleResize = () => {
      if (window.innerWidth >= 1024) {
        setIsMobileMenuOpen(false);
      }
    };
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  return (
    <header
      className={cn(
        'fixed top-0 left-0 right-0 z-50 transition-all duration-300',
        (isScrolled || isMobileMenuOpen)
          ? 'bg-background/95 backdrop-blur-md shadow-md py-4 md:py-5'
          : 'bg-transparent py-6 md:py-10'
      )}
    >
      <div className="w-full px-6 md:px-12">
        <nav className="flex items-center h-full">
          {/* Logo - Left Corner */}
          <div className="flex-shrink-0">
            <Link to="/" className="flex items-center gap-3 group">
              <div className="w-10 h-10 bg-accent rounded-xl flex items-center justify-center group-hover:scale-105 transition-transform shrink-0">
                <Scale className="w-6 h-6 text-accent-foreground" />
              </div>
              <div className="flex flex-col">
                <span className={cn(
                  'font-display text-base sm:text-xl md:text-2xl font-bold tracking-tight transition-colors leading-none',
                  (isScrolled || isMobileMenuOpen) ? 'text-foreground' : 'text-white'
                )}>
                  {settings.firmName.split(' ')[0]}
                </span>
                <span className={cn(
                  'text-[8px] sm:text-xs tracking-[0.2em] uppercase transition-colors mt-0.5',
                  (isScrolled || isMobileMenuOpen) ? 'text-muted-foreground' : 'text-white/70'
                )}>
                  {settings.firmName.split(' ').slice(1).join(' ')}
                </span>
              </div>
            </Link>
          </div>

          {/* Right Side Navigation & CTA */}
          <div className="flex flex-1 items-center justify-end gap-8 xl:gap-12">
            {/* Navigation Links - Desktop Only */}
            <div className="hidden lg:flex items-center gap-8 xl:gap-10">
              {navLinks.map((link) => (
                <Link
                  key={link.path}
                  to={link.path}
                  className={cn(
                    'text-base font-semibold transition-colors relative whitespace-nowrap',
                    isActive(link.path)
                      ? 'text-accent'
                      : (isScrolled || isMobileMenuOpen)
                        ? 'text-foreground hover:text-accent'
                        : 'text-white/90 hover:text-white',
                    'after:absolute after:bottom-[-4px] after:left-0 after:h-0.5 after:bg-accent after:transition-all after:duration-300',
                    isActive(link.path) ? 'after:w-full' : 'after:w-0 hover:after:w-full'
                  )}
                >
                  {t(link.name)}
                </Link>
              ))}
            </div>

            {/* Desktop & Mobile CTA Buttons */}
            <div className="flex items-center gap-2 sm:gap-4">
              {/* Phone (Desktop Only) */}
              <div
                className={cn(
                  'hidden xl:flex items-center gap-2 text-sm font-medium mr-2',
                  (isScrolled || isMobileMenuOpen) ? 'text-foreground' : 'text-white'
                )}
              >
                <Phone className="w-4 h-4" />
                <span>{settings.phone}</span>
              </div>

              {/* Language Toggle */}
              <div className="hidden sm:block mr-2">
                <LanguageToggle />
              </div>

              {/* Inquiry Button */}
              <Link to="/inquiry" className="flex items-center shrink-0">
                <Button className={cn(
                  "bg-accent text-white hover:bg-gold-dark shadow-gold transition-all duration-300",
                  "h-9 sm:h-12 px-3 sm:px-6 text-xs sm:text-sm font-bold hover:scale-105"
                )}>
                  <span className="hidden sm:inline">{t('common.bookConsultation')}</span>
                  <span className="sm:hidden">{t('navigation.inquiry')}</span>
                </Button>
              </Link>

              {/* Mobile Menu Button */}
              <button
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
                className={cn(
                  'lg:hidden flex items-center justify-center p-2 transition-all duration-300 z-[110] rounded-xl ml-1',
                  (isScrolled || isMobileMenuOpen)
                    ? 'text-foreground hover:bg-accent/10' 
                    : 'text-white hover:bg-white/10'
                )}
                aria-label="Toggle Menu"
              >
                {isMobileMenuOpen ? (
                  <X className="w-7 h-7" />
                ) : (
                  <Menu className="w-7 h-7" />
                )}
              </button>
            </div>
          </div>
        </nav>
      </div>

      {/* Mobile Menu Overlay - Drawer Style */}
      <div className={cn(
        'lg:hidden fixed left-0 right-0 top-0 bg-background transition-all duration-500 ease-in-out z-[100] overflow-hidden',
        isMobileMenuOpen ? 'h-screen opacity-100' : 'h-0 opacity-0 pointer-events-none'
      )}>
        {/* Decorative background elements */}
        <div className="absolute top-0 right-0 w-64 h-64 bg-accent/5 rounded-full blur-3xl -translate-y-1/2 translate-x-1/2" />
        <div className="absolute bottom-0 left-0 w-64 h-64 bg-gold-light/5 rounded-full blur-3xl translate-y-1/2 -translate-x-1/2" />
        
        <div className="container-legal relative flex flex-col pt-16 md:pt-20 pb-8 overflow-y-auto no-scrollbar h-full">
          <nav className="py-2">
            <div className="flex flex-col gap-2">
              {navLinks.map((link, index) => (
                <Link
                  key={link.path}
                  to={link.path}
                  onClick={() => setIsMobileMenuOpen(false)}
                  className={cn(
                    'group flex items-center justify-between py-3 md:py-4 text-xl sm:text-2xl md:text-3xl font-display font-semibold transition-all duration-300',
                    isActive(link.path) ? 'text-accent pl-2' : 'text-foreground hover:text-accent pl-0 hover:pl-2',
                    isMobileMenuOpen ? 'translate-y-0 opacity-100' : 'translate-y-10 opacity-0'
                  )}
                  style={{ transitionDelay: `${index * 100}ms` }}
                >
                  <span>{t(link.name)}</span>
                  <div className={cn(
                    'w-2 h-2 rounded-full bg-accent transition-all duration-300',
                    isActive(link.path) ? 'opacity-100 scale-100' : 'opacity-0 scale-0 group-hover:opacity-100 group-hover:scale-100'
                  )} />
                </Link>
              ))}
            </div>
          </nav>
          
          <div className={cn(
            "mt-auto pt-6 border-t border-border/50 shrink-0 space-y-6 transition-all duration-500 delay-500",
            isMobileMenuOpen ? "translate-y-0 opacity-100" : "translate-y-10 opacity-0"
          )}>
            <div>
              <div className="flex items-center justify-between p-5 rounded-xl bg-muted/50">
                <div className="flex flex-col">
                  <div className="text-[10px] uppercase tracking-widest text-muted-foreground font-semibold">Language / भाषा</div>
                  <div className="text-xs font-medium text-foreground">{isMarathi ? 'मराठी' : 'English'}</div>
                </div>
                <LanguageToggle />
              </div>
            </div>
            
            <Link to="/inquiry" onClick={() => setIsMobileMenuOpen(false)}>
              <Button className="btn-gold w-full py-6 h-auto text-lg font-bold shadow-gold group">
                <span className="flex items-center gap-2">
                  {t('common.bookConsultation')}
                  <svg className="w-5 h-5 transition-transform group-hover:translate-x-1" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                    <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2} d="M14 5l7 7m0 0l-7 7m7-7H3" />
                  </svg>
                </span>
              </Button>
            </Link>
          </div>
        </div>
      </div>
    </header>
  );
};
