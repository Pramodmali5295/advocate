import { useState, type ReactNode } from 'react';
import { useContent } from '@/context/ContentContext';
import { Button } from '@/components/ui/button';
import { useToast } from '@/hooks/use-toast';
import {
  Home, Info, Briefcase, MessageSquare, BookOpen, Phone,
  Save, RotateCcw, Plus, Trash2, ChevronDown, ChevronUp,
  Eye
} from 'lucide-react';

const tabs = [
  { id: 'home',         label: 'Home Page',      icon: Home,         route: '/' },
  { id: 'about',        label: 'About Page',      icon: Info,         route: '/about' },
  { id: 'practice',     label: 'Practice Areas',  icon: Briefcase,    route: '/practice-areas' },
  { id: 'testimonials', label: 'Testimonials',    icon: MessageSquare,route: '/ (Home)' },
  { id: 'knowledge',    label: 'Knowledge Base',  icon: BookOpen,     route: '/knowledge' },
  { id: 'contact',      label: 'Contact Page',    icon: Phone,        route: '/contact' },
];

// ─── Reusable Components ─────────────────────────────────────────────────────

/** Card with a title and a small "appears on: X page" hint */
const SectionCard = ({
  title,
  page,
  hint,
  children,
}: {
  title: string;
  page: string;
  hint?: string;
  children: ReactNode;
}) => (
  <div className="admin-card space-y-4">
    <div className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-1 border-b border-border pb-3">
      <h3 className="font-display text-base font-semibold text-foreground">{title}</h3>
      <div className="flex items-center gap-1.5 text-xs text-muted-foreground bg-muted px-2.5 py-1 rounded-full w-fit">
        <Eye className="w-3 h-3" />
        <span>Appears on: <strong className="text-foreground">{page}</strong></span>
      </div>
    </div>
    {hint && (
      <p className="text-xs text-muted-foreground bg-accent/5 border border-accent/20 rounded-lg px-3 py-2">
        💡 {hint}
      </p>
    )}
    {children}
  </div>
);

const Field = ({ label, hint, children }: { label: string; hint?: string; children: ReactNode }) => (
  <div>
    <label className="form-label">{label}</label>
    {hint && <p className="text-xs text-muted-foreground mb-1">{hint}</p>}
    {children}
  </div>
);

// ─── Home Tab ────────────────────────────────────────────────────────────────
const HomeTab = () => {
  const { content, updateHero, updateAboutSection, updateCTA } = useContent();
  const { toast } = useToast();
  const [hero, setHero]   = useState(content.hero);
  const [about, setAbout] = useState(content.aboutSection);
  const [cta, setCta]     = useState(content.cta);

  const save = () => {
    updateHero(hero);
    updateAboutSection(about);
    updateCTA(cta);
    toast({ title: 'Home Page Saved', description: 'All changes are now live on the Home page.' });
  };

  return (
    <div className="space-y-6">

      {/* ── Section 1: Top Banner / Hero ── */}
      <SectionCard
        title="Top Banner — Hero Section"
        page="Home Page ( / )"
        hint="This is the very first thing visitors see when they open the website — the full-screen dark banner at the top."
      >
        <Field
          label="Small Badge Text (above the main heading)"
          hint='e.g. "20+ YEARS OF LEGAL EXCELLENCE" — shown in a pill/badge above the big title.'
        >
          <input className="form-input" value={hero.badge} onChange={e => setHero({ ...hero, badge: e.target.value })} />
        </Field>

        <Field
          label='Main Heading — "Justice Delivered with…" line'
          hint="The large white heading text in the centre of the banner."
        >
          <textarea className="form-input min-h-[80px]" value={hero.title} onChange={e => setHero({ ...hero, title: e.target.value })} />
        </Field>

        <Field
          label="Description Text (below the main heading)"
          hint="The smaller paragraph text below the big heading that describes the firm's services."
        >
          <textarea className="form-input min-h-[80px]" value={hero.subtitle} onChange={e => setHero({ ...hero, subtitle: e.target.value })} />
        </Field>

        <div>
          <label className="form-label">Statistics Row (Cases Won / Years Experience / Success Rate…)</label>
          <p className="text-xs text-muted-foreground mb-2">These numbers appear at the bottom of the banner in a row of stat boxes.</p>
          <div className="grid sm:grid-cols-3 gap-3">
            {hero.stats.map((stat, i) => (
              <div key={i} className="border border-border rounded-lg p-3 space-y-2 bg-muted/30">
                <input
                  className="form-input text-sm font-bold"
                  placeholder="Number, e.g. 2,500+"
                  value={stat.value}
                  onChange={e => { const s = [...hero.stats]; s[i] = { ...s[i], value: e.target.value }; setHero({ ...hero, stats: s }); }}
                />
                <input
                  className="form-input text-sm"
                  placeholder="Label, e.g. Cases Won"
                  value={stat.label}
                  onChange={e => { const s = [...hero.stats]; s[i] = { ...s[i], label: e.target.value }; setHero({ ...hero, stats: s }); }}
                />
              </div>
            ))}
          </div>
        </div>
      </SectionCard>

      {/* ── Section 2: "About the Advocate" on home ── */}
      <SectionCard
        title={`"About the Advocate" Section`}
        page="Home Page ( / ) — middle section"
        hint="This is the two-column section on the Home page with the advocate's photo placeholder on the left and text on the right. It is NOT the full About page — just a summary."
      >
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Advocate's Full Name (shown in the photo card)">
            <input className="form-input" value={about.name} onChange={e => setAbout({ ...about, name: e.target.value })} />
          </Field>
          <Field label="Designation / Title (shown below the name in the card)">
            <input className="form-input" placeholder="e.g. Senior Advocate" value={about.title} onChange={e => setAbout({ ...about, title: e.target.value })} />
          </Field>
          <Field label="Years of Experience (shown in the gold badge on the photo)">
            <input className="form-input" placeholder="e.g. 20+" value={about.experience} onChange={e => setAbout({ ...about, experience: e.target.value })} />
          </Field>
          <Field label="Total Cases Handled">
            <input className="form-input" placeholder="e.g. 2,500+" value={about.casesHandled} onChange={e => setAbout({ ...about, casesHandled: e.target.value })} />
          </Field>
        </div>
        <Field
          label="About Description Paragraph (the two lines of text on the right side)"
          hint="Keep this concise — it's a short introduction that links to the full About page."
        >
          <textarea className="form-input min-h-[100px]" value={about.description} onChange={e => setAbout({ ...about, description: e.target.value })} />
        </Field>
        <div>
          <label className="form-label">Highlight Stats (the icon + number + label boxes shown in a grid)</label>
          <p className="text-xs text-muted-foreground mb-2">e.g. "Supreme Court Practice — 20+" or "Success Rate — 98%"</p>
          <div className="grid sm:grid-cols-2 gap-3">
            {about.highlights.map((h, i) => (
              <div key={i} className="flex gap-2 items-start border border-border rounded-lg p-2">
                <div className="flex-1">
                  <input className="form-input text-sm mb-1" placeholder="Label, e.g. Supreme Court Practice" value={h.label} onChange={e => { const arr = [...about.highlights]; arr[i] = { ...arr[i], label: e.target.value }; setAbout({ ...about, highlights: arr }); }} />
                </div>
                <input className="form-input text-sm w-20" placeholder="Value" value={h.value} onChange={e => { const arr = [...about.highlights]; arr[i] = { ...arr[i], value: e.target.value }; setAbout({ ...about, highlights: arr }); }} />
              </div>
            ))}
          </div>
        </div>
      </SectionCard>

      {/* ── Section 3: "Ready to Discuss…" CTA ── */}
      <SectionCard
        title={`"Ready to Discuss Your Legal Matter?" — Call-to-Action Section`}
        page="Home Page ( / ) — near the bottom"
        hint={`This is the dark navy banner near the bottom of the Home page with the "Book Consultation" button and four feature cards (24-Hour Response, Confidential, etc.).`}
      >
        <Field label={`Main Heading (e.g. "Ready to Discuss Your Legal Matter?")`}>
          <input className="form-input" value={cta.title} onChange={e => setCta({ ...cta, title: e.target.value })} />
        </Field>
        <Field label="Description Paragraph (below the heading)">
          <textarea className="form-input min-h-[80px]" value={cta.subtitle} onChange={e => setCta({ ...cta, subtitle: e.target.value })} />
        </Field>
        <div>
          <label className="form-label">Four Feature Cards (24-Hour Response / Confidential / Direct Access / Clear Guidance)</label>
          <p className="text-xs text-muted-foreground mb-2">Each card has a title and a short description shown in the grid on the right side of this section.</p>
          <div className="space-y-3">
            {cta.features.map((f, i) => (
              <div key={i} className="border border-border rounded-lg p-3 space-y-2 bg-muted/20">
                <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Card {i + 1}</span>
                <input className="form-input text-sm font-semibold" placeholder="Card Title, e.g. 24-Hour Response" value={f.title} onChange={e => { const arr = [...cta.features]; arr[i] = { ...arr[i], title: e.target.value }; setCta({ ...cta, features: arr }); }} />
                <input className="form-input text-sm" placeholder="Card Description" value={f.description} onChange={e => { const arr = [...cta.features]; arr[i] = { ...arr[i], description: e.target.value }; setCta({ ...cta, features: arr }); }} />
              </div>
            ))}
          </div>
        </div>
      </SectionCard>

      <div className="flex justify-end">
        <Button onClick={save} className="btn-gold"><Save className="w-4 h-4 mr-2" />Save & Publish Home Page</Button>
      </div>
    </div>
  );
};

// ─── About Tab ───────────────────────────────────────────────────────────────
const AboutTab = () => {
  const { content, updateAboutPage } = useContent();
  const { toast } = useToast();
  const [data, setData] = useState(content.aboutPage);

  const save = () => {
    updateAboutPage(data);
    toast({ title: 'About Page Saved', description: 'All changes are now live on the About page.' });
  };

  const updateTimeline = (i: number, field: string, value: string) => {
    const arr = [...data.timeline]; arr[i] = { ...arr[i], [field]: value }; setData({ ...data, timeline: arr });
  };
  const addTimeline    = () => setData({ ...data, timeline: [...data.timeline, { year: '', title: '', description: '' }] });
  const removeTimeline = (i: number) => setData({ ...data, timeline: data.timeline.filter((_, idx) => idx !== i) });

  const updateCert = (i: number, value: string) => { const arr = [...data.certifications]; arr[i] = value; setData({ ...data, certifications: arr }); };
  const addCert    = () => setData({ ...data, certifications: [...data.certifications, ''] });
  const removeCert = (i: number) => setData({ ...data, certifications: data.certifications.filter((_, idx) => idx !== i) });

  const updateBio = (i: number, value: string) => { const arr = [...data.bio]; arr[i] = value; setData({ ...data, bio: arr }); };

  return (
    <div className="space-y-6">

      {/* Top Banner of About page */}
      <SectionCard
        title="Top Banner — About Page Header"
        page="About Page ( /about ) — top dark section"
        hint="The full-width dark navy header at the top of the /about page, showing the page title and the advocate's profile sidebar."
      >
        <div className="grid sm:grid-cols-2 gap-4">
          <Field label="Advocate's Full Name (shown in the profile sidebar card)">
            <input className="form-input" value={data.advocateName} onChange={e => setData({ ...data, advocateName: e.target.value })} />
          </Field>
          <Field label="Designation / Title (shown below name in sidebar)">
            <input className="form-input" placeholder="e.g. Senior Advocate" value={data.advocateTitle} onChange={e => setData({ ...data, advocateTitle: e.target.value })} />
          </Field>
          <Field label="Education / Bar Enrollment (shown with graduation icon in sidebar)">
            <input className="form-input" placeholder="e.g. LLB, Delhi University" value={data.education} onChange={e => setData({ ...data, education: e.target.value })} />
          </Field>
          <Field label="Location / City (shown with map pin icon in sidebar)">
            <input className="form-input" placeholder="e.g. New Delhi, India" value={data.location} onChange={e => setData({ ...data, location: e.target.value })} />
          </Field>
        </div>
        <Field label='Page Heading (big text in dark banner, e.g. "Committed to Justice…")'>
          <input className="form-input" value={data.heroTitle} onChange={e => setData({ ...data, heroTitle: e.target.value })} />
        </Field>
        <Field label="Sub-heading Description (below the page heading in the dark banner)">
          <textarea className="form-input min-h-[80px]" value={data.heroSubtitle} onChange={e => setData({ ...data, heroSubtitle: e.target.value })} />
        </Field>
      </SectionCard>

      {/* Biography Section */}
      <SectionCard
        title='"Biography" Section'
        page="About Page ( /about ) — main content area"
        hint='The "Biography" heading and paragraphs of text shown in the right-hand content column on the About page.'
      >
        {data.bio.map((p, i) => (
          <Field key={i} label={`Biography Paragraph ${i + 1}`}>
            <textarea className="form-input min-h-[80px]" value={p} onChange={e => updateBio(i, e.target.value)} />
          </Field>
        ))}
      </SectionCard>

      {/* Certifications */}
      <SectionCard
        title='"Certifications & Memberships" Section'
        page="About Page ( /about ) — below Biography"
        hint='Each item appears as a checkbox row in the "Certifications & Memberships" section on the About page.'
      >
        <div className="space-y-2">
          {data.certifications.map((c, i) => (
            <div key={i} className="flex gap-2">
              <input className="form-input text-sm flex-1" placeholder="e.g. Bar Council of Delhi — Enrollment No. D/123/2003" value={c} onChange={e => updateCert(i, e.target.value)} />
              <button onClick={() => removeCert(i)} className="p-2 text-destructive hover:bg-destructive/10 rounded-lg"><Trash2 className="w-4 h-4" /></button>
            </div>
          ))}
        </div>
        <Button variant="outline" onClick={addCert} className="w-full"><Plus className="w-4 h-4 mr-2" />Add Certification / Membership</Button>
      </SectionCard>

      {/* Professional Journey Timeline */}
      <SectionCard
        title='"Professional Journey" Timeline'
        page="About Page ( /about ) — below Certifications"
        hint='Each entry appears as a numbered timeline card with a Year, Title, and Description on the About page.'
      >
        <div className="space-y-3">
          {data.timeline.map((t, i) => (
            <div key={i} className="border border-border rounded-lg p-3 space-y-2 bg-muted/20">
              <div className="flex items-center justify-between">
                <span className="text-xs font-semibold text-muted-foreground uppercase tracking-wider">Timeline Entry {i + 1}</span>
                <button onClick={() => removeTimeline(i)} className="p-1 text-destructive hover:bg-destructive/10 rounded-lg"><Trash2 className="w-4 h-4" /></button>
              </div>
              <div className="flex gap-2">
                <input className="form-input text-sm w-24" placeholder="Year, e.g. 2003" value={t.year} onChange={e => updateTimeline(i, 'year', e.target.value)} />
                <input className="form-input text-sm flex-1" placeholder="Title, e.g. Enrolled with Bar Council" value={t.title} onChange={e => updateTimeline(i, 'title', e.target.value)} />
              </div>
              <input className="form-input text-sm" placeholder="Short description for this milestone" value={t.description} onChange={e => updateTimeline(i, 'description', e.target.value)} />
            </div>
          ))}
        </div>
        <Button variant="outline" onClick={addTimeline} className="w-full"><Plus className="w-4 h-4 mr-2" />Add Timeline Entry</Button>
      </SectionCard>

      {/* Ethics */}
      <SectionCard
        title={`"Our Ethical Commitment" Statement`}
        page="About Page ( /about ) — bottom dark card"
        hint={`This text appears in the dark navy box at the bottom of the About page under the heading "Our Ethical Commitment".`}
      >
        <Field label="Ethics Statement Text">
          <textarea className="form-input min-h-[100px]" value={data.ethicsStatement} onChange={e => setData({ ...data, ethicsStatement: e.target.value })} />
        </Field>
      </SectionCard>

      <div className="flex justify-end">
        <Button onClick={save} className="btn-gold"><Save className="w-4 h-4 mr-2" />Save & Publish About Page</Button>
      </div>
    </div>
  );
};

// ─── Practice Areas Tab ──────────────────────────────────────────────────────
const PracticeAreasTab = () => {
  const { content, updatePracticeAreas } = useContent();
  const { toast } = useToast();
  const [areas, setAreas]       = useState(content.practiceAreas);
  const [expanded, setExpanded] = useState<string | null>(null);

  const update       = (id: string, field: string, value: unknown) => setAreas(areas.map(a => a.id === id ? { ...a, [field]: value } : a));
  const updateList   = (id: string, field: 'services' | 'courts', i: number, value: string) => {
    setAreas(areas.map(a => { if (a.id !== id) return a; const arr = [...a[field]]; arr[i] = value; return { ...a, [field]: arr }; }));
  };
  const addListItem    = (id: string, field: 'services' | 'courts') => setAreas(areas.map(a => a.id === id ? { ...a, [field]: [...a[field], ''] } : a));
  const removeListItem = (id: string, field: 'services' | 'courts', i: number) => setAreas(areas.map(a => a.id === id ? { ...a, [field]: a[field].filter((_, idx) => idx !== i) } : a));

  const save = () => { updatePracticeAreas(areas); toast({ title: 'Practice Areas Saved', description: 'Changes are now live on /practice-areas.' }); };

  return (
    <div className="space-y-4">
      <div className="bg-accent/5 border border-accent/20 rounded-lg p-4 text-sm text-muted-foreground">
        💡 Each card below is a Practice Area shown on <strong className="text-foreground">/practice-areas</strong> page and also in the <strong className="text-foreground">Practice Areas grid on the Home page</strong>. Use the <strong className="text-foreground">Active / Hidden</strong> toggle to show or hide a card on the website.
      </div>

      {areas.map(area => (
        <div key={area.id} className="admin-card">
          {/* Row header */}
          <div className="flex items-center justify-between cursor-pointer" onClick={() => setExpanded(expanded === area.id ? null : area.id)}>
            <div className="flex items-center gap-3">
              <span className={`w-3 h-3 rounded-full flex-shrink-0 ${area.isActive ? 'bg-green-500' : 'bg-muted-foreground'}`} />
              <div>
                <span className="font-semibold text-foreground">{area.title}</span>
                <span className="ml-2 text-xs text-muted-foreground">{area.cases} cases · {area.successRate} success rate</span>
              </div>
            </div>
            <div className="flex items-center gap-2">
              <button
                onClick={e => { e.stopPropagation(); update(area.id, 'isActive', !area.isActive); }}
                className={`text-xs px-3 py-1 rounded-full font-medium transition-colors ${area.isActive ? 'bg-green-100 text-green-700 hover:bg-green-200' : 'bg-muted text-muted-foreground hover:bg-muted/80'}`}
              >
                {area.isActive ? '✓ Visible on Website' : '✕ Hidden from Website'}
              </button>
              {expanded === area.id ? <ChevronUp className="w-4 h-4 text-muted-foreground" /> : <ChevronDown className="w-4 h-4 text-muted-foreground" />}
            </div>
          </div>

          {/* Expanded edit area */}
          {expanded === area.id && (
            <div className="mt-4 pt-4 border-t border-border space-y-5">
              <p className="text-xs text-muted-foreground bg-muted rounded-lg px-3 py-2">
                <strong>Card Title</strong> and <strong>Short Description</strong> appear on the grid card (Home &amp; /practice-areas listing page).
                The <strong>Full Description</strong> appears only on the individual detail page at <strong>/practice-areas/{area.id}</strong>.
              </p>

              <div className="grid sm:grid-cols-2 gap-4">
                <Field label="Practice Area Name (Card Title on the grid)">
                  <input className="form-input" value={area.title} onChange={e => update(area.id, 'title', e.target.value)} />
                </Field>
                <div className="flex gap-3">
                  <Field label="Number of Cases (e.g. 800+)">
                    <input className="form-input" placeholder="800+" value={area.cases} onChange={e => update(area.id, 'cases', e.target.value)} />
                  </Field>
                  <Field label="Success Rate (e.g. 95%)">
                    <input className="form-input" placeholder="95%" value={area.successRate} onChange={e => update(area.id, 'successRate', e.target.value)} />
                  </Field>
                </div>
              </div>

              <Field
                label="Short Description (shown on the card under the title)"
                hint="Keep to 1–2 sentences. This appears on the grid card on both the Home page and the /practice-areas listing."
              >
                <textarea className="form-input min-h-[60px]" value={area.description} onChange={e => update(area.id, 'description', e.target.value)} />
              </Field>

              <Field
                label="Full Description (shown at the top of the individual Practice Area detail page)"
                hint={`This longer paragraph appears when someone clicks on this card and lands on /practice-areas/${area.id}.`}
              >
                <textarea className="form-input min-h-[80px]" value={area.fullDescription} onChange={e => update(area.id, 'fullDescription', e.target.value)} />
              </Field>

              <div className="grid sm:grid-cols-2 gap-6">
                <div>
                  <label className="form-label">Services Offered (checklist on the detail page)</label>
                  <p className="text-xs text-muted-foreground mb-2">Each item appears as a green-tick checklist item on the detail page under "Services We Offer".</p>
                  <div className="space-y-2">
                    {area.services.map((s, i) => (
                      <div key={i} className="flex gap-2">
                        <input className="form-input text-sm flex-1" placeholder="e.g. Bail Applications & Hearings" value={s} onChange={e => updateList(area.id, 'services', i, e.target.value)} />
                        <button onClick={() => removeListItem(area.id, 'services', i)} className="text-destructive p-1 hover:bg-destructive/10 rounded"><Trash2 className="w-4 h-4" /></button>
                      </div>
                    ))}
                    <Button variant="outline" size="sm" onClick={() => addListItem(area.id, 'services')} className="w-full"><Plus className="w-3 h-3 mr-1" />Add Service</Button>
                  </div>
                </div>
                <div>
                  <label className="form-label">Courts & Tribunals (list on the detail page)</label>
                  <p className="text-xs text-muted-foreground mb-2">Each item appears under "Courts & Tribunals" on the detail page with a gavel icon.</p>
                  <div className="space-y-2">
                    {area.courts.map((c, i) => (
                      <div key={i} className="flex gap-2">
                        <input className="form-input text-sm flex-1" placeholder="e.g. Supreme Court of India" value={c} onChange={e => updateList(area.id, 'courts', i, e.target.value)} />
                        <button onClick={() => removeListItem(area.id, 'courts', i)} className="text-destructive p-1 hover:bg-destructive/10 rounded"><Trash2 className="w-4 h-4" /></button>
                      </div>
                    ))}
                    <Button variant="outline" size="sm" onClick={() => addListItem(area.id, 'courts')} className="w-full"><Plus className="w-3 h-3 mr-1" />Add Court / Tribunal</Button>
                  </div>
                </div>
              </div>
            </div>
          )}
        </div>
      ))}

      <div className="flex justify-end pt-2">
        <Button onClick={save} className="btn-gold"><Save className="w-4 h-4 mr-2" />Save & Publish Practice Areas</Button>
      </div>
    </div>
  );
};

// ─── Testimonials Tab ─────────────────────────────────────────────────────────
const TestimonialsTab = () => {
  const { content, updateTestimonials } = useContent();
  const { toast } = useToast();
  const [items, setItems] = useState(content.testimonials);

  const update = (id: number, field: string, value: unknown) => setItems(items.map(t => t.id === id ? { ...t, [field]: value } : t));
  const add    = () => setItems([...items, { id: Date.now(), name: '', role: '', content: '', rating: 5, location: '' }]);
  const remove = (id: number) => setItems(items.filter(t => t.id !== id));

  const save = () => { updateTestimonials(items); toast({ title: 'Testimonials Saved', description: 'Changes are now live on the Home page.' }); };

  return (
    <div className="space-y-4">
      <div className="bg-accent/5 border border-accent/20 rounded-lg p-4 text-sm text-muted-foreground">
        💡 These testimonials appear in the <strong className="text-foreground">"What Our Clients Say"</strong> sliding carousel section on the <strong className="text-foreground">Home page</strong>. They rotate every 5 seconds automatically.
      </div>

      {items.map((t) => (
        <div key={t.id} className="admin-card space-y-3">
          <div className="flex justify-between items-center">
            <span className="font-semibold text-foreground">{t.name || 'New Testimonial'}</span>
            <button onClick={() => remove(t.id)} className="p-2 text-destructive hover:bg-destructive/10 rounded-lg"><Trash2 className="w-4 h-4" /></button>
          </div>
          <div className="grid sm:grid-cols-3 gap-3">
            <Field
              label="Client's Full Name"
              hint='Shown as the bold name under the testimonial text, e.g. "Rajesh Sharma"'
            >
              <input className="form-input" value={t.name} onChange={e => update(t.id, 'name', e.target.value)} />
            </Field>
            <Field
              label="Profession / Role"
              hint='Shown next to the name, e.g. "Business Owner"'
            >
              <input className="form-input" value={t.role} onChange={e => update(t.id, 'role', e.target.value)} />
            </Field>
            <Field
              label="City"
              hint='Shown after the profession, e.g. "Delhi"'
            >
              <input className="form-input" value={t.location} onChange={e => update(t.id, 'location', e.target.value)} />
            </Field>
          </div>

          <Field
            label="Testimonial Text (the main review text shown in the large quote block)"
            hint="This is the actual review message that appears in the big sliding quote block. Keep it genuine."
          >
            <textarea className="form-input min-h-[80px]" value={t.content} onChange={e => update(t.id, 'content', e.target.value)} />
          </Field>

          <Field
            label="Star Rating (1–5 stars shown as gold stars above the quote)"
          >
            <div className="flex items-center gap-3">
              <input type="number" min="1" max="5" className="form-input w-24" value={t.rating} onChange={e => update(t.id, 'rating', parseInt(e.target.value))} />
              <span className="text-accent text-lg">{'★'.repeat(t.rating)}{'☆'.repeat(5 - t.rating)}</span>
            </div>
          </Field>
        </div>
      ))}

      <Button variant="outline" onClick={add} className="w-full"><Plus className="w-4 h-4 mr-2" />Add New Testimonial</Button>
      <div className="flex justify-end">
        <Button onClick={save} className="btn-gold"><Save className="w-4 h-4 mr-2" />Save & Publish Testimonials</Button>
      </div>
    </div>
  );
};

// ─── Knowledge Tab ────────────────────────────────────────────────────────────
const KnowledgeTab = () => {
  const { content, updateKnowledge } = useContent();
  const { toast } = useToast();
  const [articles, setArticles] = useState(content.knowledge.articles);
  const [faqs, setFaqs]         = useState(content.knowledge.faqs);

  const categories = ['Criminal Law', 'Civil Litigation', 'Family Law', 'Property Law', 'Corporate Law', 'Consumer Law'];

  const updateArticle = (id: number, field: string, value: unknown) => setArticles(articles.map(a => a.id === id ? { ...a, [field]: value } : a));
  const addArticle    = () => setArticles([...articles, { id: Date.now(), title: '', excerpt: '', category: 'Criminal Law', date: new Date().toISOString().split('T')[0], readTime: '5 min read', featured: false }]);
  const removeArticle = (id: number) => setArticles(articles.filter(a => a.id !== id));

  const updateFaq = (i: number, field: string, value: string) => { const arr = [...faqs]; arr[i] = { ...arr[i], [field]: value }; setFaqs(arr); };
  const addFaq    = () => setFaqs([...faqs, { question: '', answer: '' }]);
  const removeFaq = (i: number) => setFaqs(faqs.filter((_, idx) => idx !== i));

  const save = () => { updateKnowledge({ articles, faqs }); toast({ title: 'Knowledge Base Saved', description: 'Changes are now live on /knowledge.' }); };

  return (
    <div className="space-y-6">

      {/* Articles */}
      <SectionCard
        title="Articles — Knowledge Base"
        page="Knowledge Base Page ( /knowledge )"
        hint='Articles appear as cards on the /knowledge page. "Featured" articles are displayed in the larger two-column grid at the top; others appear in the list below.'
      >
        <div className="space-y-4">
          {articles.map(a => (
            <div key={a.id} className="border border-border rounded-lg p-4 space-y-3 bg-muted/10">
              <div className="flex items-center justify-between">
                <span className="font-medium text-sm text-foreground">{a.title || 'New Article'}</span>
                <button onClick={() => removeArticle(a.id)} className="text-destructive hover:bg-destructive/10 p-1 rounded"><Trash2 className="w-4 h-4" /></button>
              </div>
              <Field label="Article Title (the heading shown on the card)">
                <input className="form-input" value={a.title} onChange={e => updateArticle(a.id, 'title', e.target.value)} />
              </Field>
              <Field
                label="Excerpt / Summary (the 2–3 line description shown under the title on the card)"
              >
                <textarea className="form-input min-h-[60px]" value={a.excerpt} onChange={e => updateArticle(a.id, 'excerpt', e.target.value)} />
              </Field>
              <div className="grid sm:grid-cols-3 gap-3">
                <Field label="Category (filter tag on the card)">
                  <select className="form-input" value={a.category} onChange={e => updateArticle(a.id, 'category', e.target.value)}>
                    {categories.map(c => <option key={c}>{c}</option>)}
                  </select>
                </Field>
                <Field label="Published Date">
                  <input type="date" className="form-input" value={a.date} onChange={e => updateArticle(a.id, 'date', e.target.value)} />
                </Field>
                <Field label='Read Time (e.g. "5 min read")'>
                  <input className="form-input" placeholder="5 min read" value={a.readTime} onChange={e => updateArticle(a.id, 'readTime', e.target.value)} />
                </Field>
              </div>
              <label className="flex items-center gap-2 cursor-pointer select-none">
                <input type="checkbox" checked={a.featured} onChange={e => updateArticle(a.id, 'featured', e.target.checked)} className="w-4 h-4 accent-amber-500" />
                <span className="text-sm text-foreground font-medium">⭐ Featured Article</span>
                <span className="text-xs text-muted-foreground">(featured articles show in the larger top grid)</span>
              </label>
            </div>
          ))}
          <Button variant="outline" onClick={addArticle} className="w-full"><Plus className="w-4 h-4 mr-2" />Add New Article</Button>
        </div>
      </SectionCard>

      {/* FAQs */}
      <SectionCard
        title='"Frequently Asked Questions" Section'
        page="Knowledge Base Page ( /knowledge ) — bottom section"
        hint='These Q&A pairs appear in the accordion list at the bottom of the /knowledge page under the heading "Frequently Asked Questions". Click a question to expand its answer.'
      >
        <div className="space-y-4">
          {faqs.map((f, i) => (
            <div key={i} className="border border-border rounded-lg p-4 space-y-3 bg-muted/10">
              <div className="flex items-center justify-between">
                <span className="text-sm font-medium text-foreground">FAQ #{i + 1}</span>
                <button onClick={() => removeFaq(i)} className="text-destructive hover:bg-destructive/10 p-1 rounded"><Trash2 className="w-4 h-4" /></button>
              </div>
              <Field label="Question (shown as the clickable/expandable heading)">
                <input className="form-input" value={f.question} onChange={e => updateFaq(i, 'question', e.target.value)} />
              </Field>
              <Field label="Answer (shown when the user clicks on the question to expand it)">
                <textarea className="form-input min-h-[80px]" value={f.answer} onChange={e => updateFaq(i, 'answer', e.target.value)} />
              </Field>
            </div>
          ))}
          <Button variant="outline" onClick={addFaq} className="w-full"><Plus className="w-4 h-4 mr-2" />Add New FAQ</Button>
        </div>
      </SectionCard>

      <div className="flex justify-end">
        <Button onClick={save} className="btn-gold"><Save className="w-4 h-4 mr-2" />Save & Publish Knowledge Base</Button>
      </div>
    </div>
  );
};

// ─── Contact Tab ──────────────────────────────────────────────────────────────
const ContactTab = () => {
  const { content, updateContact } = useContent();
  const { toast } = useToast();
  const [data, setData] = useState(content.contact);

  const save = () => { updateContact(data); toast({ title: 'Contact Info Saved', description: 'Changes are now live on the Contact page.' }); };

  return (
    <div className="space-y-6">
      <SectionCard
        title="Office Contact Information"
        page="Contact Page ( /contact ) & Footer (all pages)"
        hint="These details appear on the /contact page in the info cards, AND also in the website footer shown on every page."
      >
        <div className="grid sm:grid-cols-2 gap-4">
          <Field
            label="Primary Mobile Number"
            hint="Shown in the header navbar and Contact page. Tap-to-call on mobile."
          >
            <input className="form-input" placeholder="+91 98765 43210" value={data.phone} onChange={e => setData({ ...data, phone: e.target.value })} />
          </Field>
          <Field
            label="Office / Landline Number (optional)"
            hint="Shown below the primary number on the Contact page."
          >
            <input className="form-input" placeholder="+91 11 2345 6789" value={data.officePhone} onChange={e => setData({ ...data, officePhone: e.target.value })} />
          </Field>
          <Field
            label="Primary Email Address"
            hint="Shown on the Contact page. Clicking it opens the user's mail app."
          >
            <input type="email" className="form-input" placeholder="info@advocatechambers.com" value={data.email} onChange={e => setData({ ...data, email: e.target.value })} />
          </Field>
          <Field
            label="Consultation / Inquiry Email Address"
            hint="A second email shown below the primary one, specifically for case inquiries."
          >
            <input type="email" className="form-input" placeholder="cases@advocatechambers.com" value={data.inquiryEmail} onChange={e => setData({ ...data, inquiryEmail: e.target.value })} />
          </Field>
        </div>

        <Field
          label="Full Office Address (shown in the 'Office Address' card on the Contact page)"
          hint="You can use newlines for multi-line address formatting."
        >
          <textarea className="form-input min-h-[80px]" placeholder={"Chamber No. 210, Lawyers' Chambers\nDistrict Court Complex, Dwarka\nNew Delhi - 110075"} value={data.address} onChange={e => setData({ ...data, address: e.target.value })} />
        </Field>

        <Field
          label="Office Working Hours (shown in the 'Office Hours' card on the Contact page)"
          hint='Use newlines for separate days, e.g. "Mon–Sat: 10:00 AM – 6:00 PM"'
        >
          <textarea className="form-input min-h-[80px]" placeholder={"Monday – Saturday: 10:00 AM – 6:00 PM\nSunday: Closed\n(Emergency consultations available)"} value={data.hours} onChange={e => setData({ ...data, hours: e.target.value })} />
        </Field>

        <Field
          label="Google Maps Embed URL (the interactive map shown on the Contact page)"
          hint='Go to Google Maps → search your office → click "Share" → "Embed a map" → copy the src="..." URL and paste it here.'
        >
          <input className="form-input text-xs font-mono" placeholder="https://www.google.com/maps/embed?pb=..." value={data.mapEmbed} onChange={e => setData({ ...data, mapEmbed: e.target.value })} />
        </Field>
      </SectionCard>

      <div className="flex justify-end">
        <Button onClick={save} className="btn-gold"><Save className="w-4 h-4 mr-2" />Save & Publish Contact Info</Button>
      </div>
    </div>
  );
};

// ─── Main AdminPages Component ────────────────────────────────────────────────
const AdminPages = () => {
  const [activeTab, setActiveTab] = useState('home');
  const { resetToDefaults } = useContent();
  const { toast } = useToast();

  const handleReset = () => {
    if (confirm('Reset ALL website content back to the original default text? This cannot be undone.')) {
      resetToDefaults();
      toast({ title: 'Reset Complete', description: 'All content has been restored to defaults.', variant: 'destructive' });
    }
  };

  const activeTabData = tabs.find(t => t.id === activeTab);

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-start justify-between gap-4">
        <div>
          <h2 className="font-display text-xl font-semibold text-foreground">Website Page Content Manager</h2>
          <p className="text-sm text-muted-foreground mt-0.5">
            Select a tab below to edit content for that page. Changes are saved to{' '}
            <strong className="text-foreground">{activeTabData?.route}</strong> — click "Save & Publish" to go live.
          </p>
        </div>
        <Button variant="outline" onClick={handleReset} className="text-destructive border-destructive/30 hover:bg-destructive/10 shrink-0">
          <RotateCcw className="w-4 h-4 mr-2" />Reset All to Default
        </Button>
      </div>

      {/* Tabs */}
      <div className="flex flex-wrap gap-2 border-b border-border pb-4">
        {tabs.map(tab => (
          <button
            key={tab.id}
            onClick={() => setActiveTab(tab.id)}
            className={`flex items-center gap-2 px-4 py-2 rounded-lg text-sm font-medium transition-all ${
              activeTab === tab.id
                ? 'bg-accent text-accent-foreground shadow-sm'
                : 'bg-muted text-muted-foreground hover:bg-muted/80'
            }`}
          >
            <tab.icon className="w-4 h-4" />
            <span>{tab.label}</span>
            <span className={`text-[10px] hidden sm:inline ${activeTab === tab.id ? 'text-accent-foreground/70' : 'text-muted-foreground/60'}`}>
              {tab.route}
            </span>
          </button>
        ))}
      </div>

      {/* Tab Content */}
      <div>
        {activeTab === 'home'         && <HomeTab />}
        {activeTab === 'about'        && <AboutTab />}
        {activeTab === 'practice'     && <PracticeAreasTab />}
        {activeTab === 'testimonials' && <TestimonialsTab />}
        {activeTab === 'knowledge'    && <KnowledgeTab />}
        {activeTab === 'contact'      && <ContactTab />}
      </div>
    </div>
  );
};

export default AdminPages;
