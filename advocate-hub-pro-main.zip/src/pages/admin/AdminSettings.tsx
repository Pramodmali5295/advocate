import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Save, 
  CreditCard, 
  User, 
  Building,
  Bell,
  Shield,
  Mail
} from 'lucide-react';
import { useToast } from '@/hooks/use-toast';

const AdminSettings = () => {
  const { toast } = useToast();
  
  const [settings, setSettings] = useState({
    // Business Info
    firmName: 'Advocate Law Chambers',
    advocateName: 'Adv. Arun Kumar',
    email: 'contact@advocatelawchambers.com',
    phone: '+91 98765 43210',
    address: '123 Legal Tower, Civil Lines, New Delhi - 110001',
    
    // Payment Settings
    inquiryFee: 499,
    currency: 'INR',
    
    // Notification Settings
    emailNotifications: true,
    smsNotifications: false,
    
    // Security
    twoFactorAuth: false,
  });

  const handleSave = () => {
    toast({
      title: "Settings Saved",
      description: "Your settings have been updated successfully.",
    });
  };

  return (
    <div className="max-w-4xl space-y-8">
      {/* Business Information */}
      <div className="admin-card">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-accent/10 rounded-lg flex items-center justify-center">
            <Building className="w-5 h-5 text-accent" />
          </div>
          <div>
            <h2 className="font-display text-lg font-semibold text-foreground">
              Business Information
            </h2>
            <p className="text-sm text-muted-foreground">
              Your firm's public information
            </p>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-6">
          <div>
            <label className="form-label">Firm Name</label>
            <input
              type="text"
              value={settings.firmName}
              onChange={(e) => setSettings({ ...settings, firmName: e.target.value })}
              className="form-input"
            />
          </div>
          <div>
            <label className="form-label">Lead Advocate Name</label>
            <input
              type="text"
              value={settings.advocateName}
              onChange={(e) => setSettings({ ...settings, advocateName: e.target.value })}
              className="form-input"
            />
          </div>
          <div>
            <label className="form-label">Email Address</label>
            <input
              type="email"
              value={settings.email}
              onChange={(e) => setSettings({ ...settings, email: e.target.value })}
              className="form-input"
            />
          </div>
          <div>
            <label className="form-label">Phone Number</label>
            <input
              type="tel"
              value={settings.phone}
              onChange={(e) => setSettings({ ...settings, phone: e.target.value })}
              className="form-input"
            />
          </div>
          <div className="sm:col-span-2">
            <label className="form-label">Office Address</label>
            <textarea
              value={settings.address}
              onChange={(e) => setSettings({ ...settings, address: e.target.value })}
              className="form-input"
              rows={2}
            />
          </div>
        </div>
      </div>

      {/* Payment Settings */}
      <div className="admin-card">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-green-100 rounded-lg flex items-center justify-center">
            <CreditCard className="w-5 h-5 text-green-600" />
          </div>
          <div>
            <h2 className="font-display text-lg font-semibold text-foreground">
              Payment Settings
            </h2>
            <p className="text-sm text-muted-foreground">
              Configure consultation fees and payment options
            </p>
          </div>
        </div>

        <div className="grid sm:grid-cols-2 gap-6">
          <div>
            <label className="form-label">Consultation Fee (₹)</label>
            <input
              type="number"
              value={settings.inquiryFee}
              onChange={(e) => setSettings({ ...settings, inquiryFee: parseInt(e.target.value) })}
              className="form-input"
              min="99"
              max="9999"
            />
            <p className="text-xs text-muted-foreground mt-1">
              Recommended range: ₹299 - ₹999
            </p>
          </div>
          <div>
            <label className="form-label">Currency</label>
            <select
              value={settings.currency}
              onChange={(e) => setSettings({ ...settings, currency: e.target.value })}
              className="form-input"
            >
              <option value="INR">Indian Rupee (₹)</option>
            </select>
          </div>
        </div>

        <div className="mt-6 p-4 bg-amber-50 border border-amber-200 rounded-lg">
          <p className="text-sm text-amber-800">
            <strong>Razorpay Integration:</strong> Configure your Razorpay API keys in the 
            backend settings. Currently using test mode.
          </p>
        </div>
      </div>

      {/* Notification Settings */}
      <div className="admin-card">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-blue-100 rounded-lg flex items-center justify-center">
            <Bell className="w-5 h-5 text-blue-600" />
          </div>
          <div>
            <h2 className="font-display text-lg font-semibold text-foreground">
              Notifications
            </h2>
            <p className="text-sm text-muted-foreground">
              How you receive consultation notifications
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <label className="flex items-center justify-between p-4 bg-muted rounded-lg cursor-pointer">
            <div className="flex items-center gap-3">
              <Mail className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="font-medium text-foreground">Email Notifications</p>
                <p className="text-sm text-muted-foreground">Receive emails for new consultations</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.emailNotifications}
              onChange={(e) => setSettings({ ...settings, emailNotifications: e.target.checked })}
              className="w-5 h-5 rounded border-border text-accent focus:ring-accent"
            />
          </label>

          <label className="flex items-center justify-between p-4 bg-muted rounded-lg cursor-pointer">
            <div className="flex items-center gap-3">
              <Bell className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="font-medium text-foreground">SMS Notifications</p>
                <p className="text-sm text-muted-foreground">Receive SMS for urgent consultations</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.smsNotifications}
              onChange={(e) => setSettings({ ...settings, smsNotifications: e.target.checked })}
              className="w-5 h-5 rounded border-border text-accent focus:ring-accent"
            />
          </label>
        </div>
      </div>

      {/* Security Settings */}
      <div className="admin-card">
        <div className="flex items-center gap-3 mb-6">
          <div className="w-10 h-10 bg-purple-100 rounded-lg flex items-center justify-center">
            <Shield className="w-5 h-5 text-purple-600" />
          </div>
          <div>
            <h2 className="font-display text-lg font-semibold text-foreground">
              Security
            </h2>
            <p className="text-sm text-muted-foreground">
              Account security settings
            </p>
          </div>
        </div>

        <div className="space-y-4">
          <label className="flex items-center justify-between p-4 bg-muted rounded-lg cursor-pointer">
            <div className="flex items-center gap-3">
              <Shield className="w-5 h-5 text-muted-foreground" />
              <div>
                <p className="font-medium text-foreground">Two-Factor Authentication</p>
                <p className="text-sm text-muted-foreground">Add an extra layer of security</p>
              </div>
            </div>
            <input
              type="checkbox"
              checked={settings.twoFactorAuth}
              onChange={(e) => setSettings({ ...settings, twoFactorAuth: e.target.checked })}
              className="w-5 h-5 rounded border-border text-accent focus:ring-accent"
            />
          </label>

          <Button variant="outline" className="w-full sm:w-auto">
            Change Password
          </Button>
        </div>
      </div>

      {/* Save Button */}
      <div className="flex justify-end gap-4">
        <Button variant="outline">Cancel</Button>
        <Button onClick={handleSave} className="btn-gold">
          <Save className="w-4 h-4 mr-2" />
          Save Settings
        </Button>
      </div>
    </div>
  );
};

export default AdminSettings;
