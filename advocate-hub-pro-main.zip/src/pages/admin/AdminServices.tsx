import { useState } from 'react';
import { Button } from '@/components/ui/button';
import { 
  Plus, 
  Edit, 
  Trash2, 
  GripVertical,
  Scale,
  FileText,
  Users,
  Home,
  Building2,
  Briefcase,
  X
} from 'lucide-react';

const iconMap = {
  Scale,
  FileText,
  Users,
  Home,
  Building2,
  Briefcase,
};

const mockServices = [
  { 
    id: 1, 
    title: 'Criminal Law', 
    description: 'Expert defense in criminal matters including bail, trials, and appeals across all courts.',
    icon: 'Scale',
    cases: '800+',
    isActive: true,
  },
  { 
    id: 2, 
    title: 'Civil Litigation', 
    description: 'Resolution of disputes, recovery suits, and civil rights matters with strategic approach.',
    icon: 'FileText',
    cases: '600+',
    isActive: true,
  },
  { 
    id: 3, 
    title: 'Family Law', 
    description: 'Sensitive handling of divorce, custody, maintenance, and domestic matters.',
    icon: 'Users',
    cases: '400+',
    isActive: true,
  },
  { 
    id: 4, 
    title: 'Property Law', 
    description: 'Real estate disputes, title verification, registration, and property documentation.',
    icon: 'Home',
    cases: '350+',
    isActive: true,
  },
  { 
    id: 5, 
    title: 'Corporate Law', 
    description: 'Company formation, compliance, contracts, and business dispute resolution.',
    icon: 'Building2',
    cases: '250+',
    isActive: true,
  },
  { 
    id: 6, 
    title: 'Consumer Law', 
    description: 'Consumer protection cases, complaints, and disputes against businesses.',
    icon: 'Briefcase',
    cases: '200+',
    isActive: false,
  },
];

const AdminServices = () => {
  const [services, setServices] = useState(mockServices);
  const [isEditing, setIsEditing] = useState<number | null>(null);
  const [editForm, setEditForm] = useState({
    title: '',
    description: '',
    cases: '',
  });

  const handleEdit = (service: typeof mockServices[0]) => {
    setIsEditing(service.id);
    setEditForm({
      title: service.title,
      description: service.description,
      cases: service.cases,
    });
  };

  const handleSave = () => {
    setServices(services.map(s => 
      s.id === isEditing 
        ? { ...s, ...editForm }
        : s
    ));
    setIsEditing(null);
  };

  const toggleActive = (id: number) => {
    setServices(services.map(s => 
      s.id === id ? { ...s, isActive: !s.isActive } : s
    ));
  };

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center justify-between">
        <div>
          <h2 className="font-display text-xl font-semibold text-foreground">
            Practice Areas / Services
          </h2>
          <p className="text-sm text-muted-foreground">
            Manage the services displayed on your website
          </p>
        </div>
        <Button className="btn-gold">
          <Plus className="w-4 h-4 mr-2" />
          Add Service
        </Button>
      </div>

      {/* Services List */}
      <div className="space-y-4">
        {services.map((service) => {
          const IconComponent = iconMap[service.icon as keyof typeof iconMap];
          
          return (
            <div 
              key={service.id} 
              className={`admin-card flex items-start gap-4 ${!service.isActive ? 'opacity-60' : ''}`}
            >
              {/* Drag Handle */}
              <button className="p-2 hover:bg-muted rounded cursor-grab">
                <GripVertical className="w-5 h-5 text-muted-foreground" />
              </button>

              {/* Icon */}
              <div className="w-12 h-12 bg-accent/10 rounded-lg flex items-center justify-center flex-shrink-0">
                <IconComponent className="w-6 h-6 text-accent" />
              </div>

              {/* Content */}
              <div className="flex-1 min-w-0">
                {isEditing === service.id ? (
                  <div className="space-y-4">
                    <input
                      type="text"
                      value={editForm.title}
                      onChange={(e) => setEditForm({ ...editForm, title: e.target.value })}
                      className="form-input"
                      placeholder="Service Title"
                    />
                    <textarea
                      value={editForm.description}
                      onChange={(e) => setEditForm({ ...editForm, description: e.target.value })}
                      className="form-input min-h-[80px]"
                      placeholder="Description"
                    />
                    <input
                      type="text"
                      value={editForm.cases}
                      onChange={(e) => setEditForm({ ...editForm, cases: e.target.value })}
                      className="form-input"
                      placeholder="Cases handled (e.g., 500+)"
                    />
                    <div className="flex gap-3">
                      <Button onClick={handleSave} className="btn-gold">
                        Save Changes
                      </Button>
                      <Button variant="outline" onClick={() => setIsEditing(null)}>
                        Cancel
                      </Button>
                    </div>
                  </div>
                ) : (
                  <>
                    <div className="flex items-center gap-3 mb-2">
                      <h3 className="font-semibold text-foreground">{service.title}</h3>
                      {!service.isActive && (
                        <span className="px-2 py-0.5 bg-muted text-muted-foreground text-xs rounded">
                          Hidden
                        </span>
                      )}
                    </div>
                    <p className="text-sm text-muted-foreground mb-2">
                      {service.description}
                    </p>
                    <span className="text-sm text-accent font-medium">
                      {service.cases} cases handled
                    </span>
                  </>
                )}
              </div>

              {/* Actions */}
              {isEditing !== service.id && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => toggleActive(service.id)}
                    className={`px-3 py-1.5 text-xs font-medium rounded-full transition-colors ${
                      service.isActive 
                        ? 'bg-green-100 text-green-700 hover:bg-green-200' 
                        : 'bg-muted text-muted-foreground hover:bg-muted/80'
                    }`}
                  >
                    {service.isActive ? 'Active' : 'Hidden'}
                  </button>
                  <button
                    onClick={() => handleEdit(service)}
                    className="p-2 hover:bg-muted rounded-lg text-muted-foreground hover:text-foreground"
                  >
                    <Edit className="w-4 h-4" />
                  </button>
                  <button className="p-2 hover:bg-destructive/10 rounded-lg text-muted-foreground hover:text-destructive">
                    <Trash2 className="w-4 h-4" />
                  </button>
                </div>
              )}
            </div>
          );
        })}
      </div>
    </div>
  );
};

export default AdminServices;
