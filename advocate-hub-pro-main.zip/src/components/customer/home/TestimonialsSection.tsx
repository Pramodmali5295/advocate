import { Star, Quote, MapPin } from 'lucide-react';
import { useContent } from '@/context/ContentContext';

export const TestimonialsSection = () => {
  const { content } = useContent();
  const testimonials = content.testimonials;

  const getInitials = (name: string) =>
    name
      .split(' ')
      .map((w) => w[0])
      .join('')
      .slice(0, 2)
      .toUpperCase();

  return (
    <section className="section-padding bg-cream-dark scroll-mt-20" id="testimonials">
      <div className="container-legal">
        {/* Section Header */}
        <div className="text-center mb-12 md:mb-16">
          <span className="text-accent text-sm font-semibold tracking-widest uppercase mb-4 block">
            Client Testimonials
          </span>
          <h2 className="heading-section text-foreground mb-4">What Our Clients Say</h2>
          <div className="accent-line-center mb-6" />
          <p className="text-body max-w-2xl mx-auto px-4">
            Our success is measured by the satisfaction of our clients. Here's what they have to
            say about their experience working with us.
          </p>
        </div>

        {/* 5-Card Row */}
        <div
          className="grid gap-5"
          style={{ gridTemplateColumns: 'repeat(5, minmax(0, 1fr))' }}
        >
          {testimonials.map((t, index) => (
            <div
              key={t.id}
              className="relative flex flex-col bg-background rounded-2xl border border-border shadow-md hover:shadow-xl hover:-translate-y-1.5 transition-all duration-300 p-5 group overflow-hidden"
              style={{ animationDelay: `${index * 0.1}s` }}
            >
              {/* Subtle gold corner accent */}
              <div className="absolute top-0 right-0 w-16 h-16 bg-accent/5 rounded-bl-3xl rounded-tr-2xl pointer-events-none" />

              {/* Quote Icon */}
              <div className="mb-4">
                <div className="w-9 h-9 bg-accent/10 rounded-lg flex items-center justify-center group-hover:bg-accent/20 transition-colors duration-300">
                  <Quote className="w-4 h-4 text-accent" />
                </div>
              </div>

              {/* Stars */}
              <div className="flex gap-0.5 mb-3">
                {Array.from({ length: t.rating }).map((_, i) => (
                  <Star key={i} className="w-3.5 h-3.5 fill-accent text-accent" />
                ))}
              </div>

              {/* Review Text */}
              <p className="text-muted-foreground text-sm leading-relaxed flex-1 mb-5 line-clamp-5">
                "{t.content}"
              </p>

              {/* Divider */}
              <div className="border-t border-border mb-4" />

              {/* Author */}
              <div className="flex items-center gap-3">
                {/* Avatar */}
                <div className="w-10 h-10 rounded-full bg-gradient-to-br from-navy to-charcoal flex items-center justify-center flex-shrink-0 shadow-sm">
                  <span className="text-accent font-bold text-xs">{getInitials(t.name)}</span>
                </div>
                <div className="min-w-0">
                  <div className="font-semibold text-foreground text-sm truncate">{t.name}</div>
                  <div className="text-muted-foreground text-xs truncate">{t.role}</div>
                </div>
              </div>

              {/* Location badge */}
              <div className="mt-3 flex items-center gap-1 text-xs text-accent/80">
                <MapPin className="w-3 h-3 flex-shrink-0" />
                <span>{t.location}</span>
              </div>
            </div>
          ))}
        </div>

        {/* Aggregate rating summary */}
        <div className="mt-10 text-center">
          <div className="inline-flex items-center gap-3 bg-background border border-border rounded-full px-6 py-3 shadow-sm">
            <div className="flex gap-0.5">
              {[1, 2, 3, 4, 5].map((s) => (
                <Star key={s} className="w-4 h-4 fill-accent text-accent" />
              ))}
            </div>
            <span className="text-foreground font-semibold text-sm">5.0</span>
            <span className="text-muted-foreground text-sm">·</span>
            <span className="text-muted-foreground text-sm">
              Based on {testimonials.length} client reviews
            </span>
          </div>
        </div>
      </div>
    </section>
  );
};
