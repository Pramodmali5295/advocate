import { createContext, useContext, useState, useEffect, ReactNode } from 'react';

// ─── Types ────────────────────────────────────────────
export interface HeroContent {
  badge: string;
  title: string;
  subtitle: string;
  stats: { label: string; value: string }[];
}

export interface AboutSectionContent {
  name: string;
  title: string;
  experience: string;
  casesHandled: string;
  description: string;
  highlights: { label: string; value: string }[];
}

export interface CTAContent {
  title: string;
  subtitle: string;
  features: { icon: string; title: string; description: string }[];
}

export interface TestimonialItem {
  id: number;
  name: string;
  role: string;
  content: string;
  rating: number;
  location: string;
}

export interface PracticeAreaItem {
  id: string;
  icon: string;
  title: string;
  description: string;
  fullDescription: string;
  services: string[];
  courts: string[];
  cases: string;
  successRate: string;
  isActive: boolean;
}

export interface TimelineItem {
  year: string;
  title: string;
  description: string;
}

export interface AboutPageContent {
  heroTitle: string;
  heroSubtitle: string;
  advocateName: string;
  advocateTitle: string;
  education: string;
  location: string;
  bio: string[];
  certifications: string[];
  timeline: TimelineItem[];
  ethicsStatement: string;
}

export interface ArticleItem {
  id: number;
  title: string;
  excerpt: string;
  category: string;
  date: string;
  readTime: string;
  featured: boolean;
}

export interface FAQItem {
  question: string;
  answer: string;
}

export interface KnowledgeContent {
  articles: ArticleItem[];
  faqs: FAQItem[];
}

export interface ContactContent {
  address: string;
  phone: string;
  officePhone: string;
  email: string;
  inquiryEmail: string;
  hours: string;
  mapEmbed: string;
}

export interface SiteContent {
  hero: HeroContent;
  aboutSection: AboutSectionContent;
  cta: CTAContent;
  testimonials: TestimonialItem[];
  practiceAreas: PracticeAreaItem[];
  aboutPage: AboutPageContent;
  knowledge: KnowledgeContent;
  contact: ContactContent;
}

// ─── Default Content ──────────────────────────────────
export const defaultContent: SiteContent = {
  hero: {
    badge: '20+ Years of Legal Excellence',
    title: 'Expert Legal\nRepresentation\nYou Can Trust',
    subtitle: 'Dedicated advocacy for your rights. From criminal defense to corporate law, we deliver strategic, results-driven legal solutions tailored to your unique situation.',
    stats: [
      { label: 'Cases Won', value: '2,500+' },
      { label: 'Years Experience', value: '20+' },
      { label: 'Success Rate', value: '95%' },
    ],
  },
  aboutSection: {
    name: 'Adv. Arun Kumar',
    title: 'Senior Advocate – Supreme Court of India',
    experience: '20+',
    casesHandled: '2,500+',
    description: 'With over two decades of experience in criminal, civil, and corporate law, Advocate Arun Kumar has built a reputation for unwavering dedication and exceptional results. His approach combines strategic thinking with a deep commitment to justice.',
    highlights: [
      { label: 'Cases Handled', value: '2,500+' },
      { label: 'Years Experience', value: '20+' },
      { label: 'Success Rate', value: '95%' },
      { label: 'High Courts', value: '8' },
    ],
  },
  cta: {
    title: 'Ready to Get the Legal Help You Deserve?',
    subtitle: 'Book a consultation today and get a detailed legal assessment of your case within 24 hours. Our team is ready to fight for your rights.',
    features: [
      { icon: 'Clock', title: '24-Hour Response', description: 'Receive a detailed legal assessment within 24 hours of booking' },
      { icon: 'Shield', title: 'Confidential', description: 'All consultations are completely confidential and secure' },
      { icon: 'Award', title: 'Expert Guidance', description: '20+ years of expertise across all major areas of law' },
    ],
  },
  testimonials: [
    { id: 1, name: 'Rajesh Sharma', role: 'Business Owner', content: 'Advocate Kumar handled my property dispute case with exceptional professionalism. His strategic approach and deep knowledge of property law helped us secure a favorable judgment. Highly recommended for any real estate legal matters.', rating: 5, location: 'Delhi' },
    { id: 2, name: 'Priya Mehta', role: 'Corporate Executive', content: 'During a challenging family law matter, Advocate Kumar provided not just legal expertise but also emotional support. His compassionate yet strategic approach made a difficult situation manageable. Forever grateful.', rating: 5, location: 'Gurgaon' },
    { id: 3, name: 'Vikram Singh', role: 'Entrepreneur', content: 'Our company has been working with Advocate Kumar for corporate legal matters for over 5 years. His understanding of business law and quick response time have been invaluable for our operations.', rating: 5, location: 'Noida' },
    { id: 4, name: 'Anita Desai', role: 'Homemaker', content: 'I was falsely accused in a criminal case. Advocate Kumar believed in my innocence and fought tirelessly. His courtroom skills and dedication resulted in my complete acquittal. He truly fights for justice.', rating: 5, location: 'Delhi' },
    { id: 5, name: 'Suresh Nair', role: 'Software Engineer', content: 'Advocate Kumar resolved my consumer dispute against a major telecom company swiftly and efficiently. His thorough understanding of consumer law and confident advocacy saved me significant time and money.', rating: 5, location: 'Mumbai' },
  ],
  practiceAreas: [
    { id: 'criminal', icon: 'Scale', title: 'Criminal Law', description: 'Expert defense in criminal matters with a proven track record of successful representations.', fullDescription: 'Our criminal law practice offers comprehensive defense services for individuals facing criminal charges. With over 800 successful case resolutions, we bring decades of experience in navigating the complexities of criminal proceedings.', services: ['Bail Applications & Appeals', 'Criminal Trial Defense', 'White Collar Crime Defense', 'Cybercrime Cases', 'Appeals in Higher Courts', 'Anticipatory Bail', 'Quashing of FIRs', 'Criminal Writ Petitions'], courts: ['Supreme Court of India', 'Delhi High Court', 'District & Sessions Courts', 'Magistrate Courts'], cases: '800+', successRate: '96%', isActive: true },
    { id: 'civil', icon: 'FileText', title: 'Civil Litigation', description: 'Strategic resolution of civil disputes with focus on client interests.', fullDescription: 'We handle all aspects of civil litigation, from initial dispute assessment to trial and appeals. Our methodical approach ensures thorough preparation and effective advocacy for our clients.', services: ['Property Disputes', 'Recovery Suits', 'Declaratory Suits', 'Injunction Matters', 'Contract Disputes', 'Partition Suits', 'Civil Appeals', 'Execution Proceedings'], courts: ['Civil Courts', 'District Courts', 'High Court', 'Consumer Forums'], cases: '600+', successRate: '94%', isActive: true },
    { id: 'family', icon: 'Users', title: 'Family Law', description: 'Compassionate handling of sensitive family matters with discretion.', fullDescription: 'Family legal matters require sensitivity, understanding, and discretion. Our family law practice provides compassionate counsel while vigorously protecting our clients rights and interests.', services: ['Divorce Proceedings', 'Child Custody & Visitation', 'Maintenance & Alimony', 'Domestic Violence Cases', 'Guardianship Matters', 'Adoption Legal Support', 'Marriage Registration', 'Pre-nuptial Agreements'], courts: ['Family Courts', 'District Courts', 'High Court', 'Mediation Centers'], cases: '400+', successRate: '92%', isActive: true },
    { id: 'property', icon: 'Home', title: 'Property Law', description: 'Comprehensive property legal services for individuals and businesses.', fullDescription: 'Property transactions and disputes require meticulous attention to detail. Our property law practice covers all aspects of real estate legal matters, ensuring your property rights are protected.', services: ['Title Verification', 'Property Registration', 'Sale & Purchase Agreements', 'Lease Documentation', 'Property Disputes', 'Landlord-Tenant Matters', 'Development Agreements', 'RERA Compliance'], courts: ['Civil Courts', 'Revenue Courts', 'High Court', 'RERA Authority'], cases: '350+', successRate: '95%', isActive: true },
    { id: 'corporate', icon: 'Building2', title: 'Corporate Law', description: 'Business legal solutions for startups, SMEs, and corporations.', fullDescription: 'We provide comprehensive corporate legal services to businesses of all sizes. From company formation to complex commercial transactions, our team ensures your business operates within legal frameworks.', services: ['Company Registration', 'Contract Drafting & Review', 'Shareholder Agreements', 'Corporate Compliance', 'Mergers & Acquisitions', 'Intellectual Property', 'Employment Contracts', 'Commercial Litigation'], courts: ['NCLT', 'High Court', 'Commercial Courts', 'Arbitration Tribunals'], cases: '250+', successRate: '97%', isActive: true },
    { id: 'consumer', icon: 'Briefcase', title: 'Consumer Law', description: 'Protection of consumer rights against unfair trade practices.', fullDescription: 'When businesses fail to deliver on promises or engage in unfair practices, we stand with consumers. Our consumer law practice helps clients seek redressal and justice against corporate wrongdoing.', services: ['Consumer Complaints', 'Product Liability', 'Service Deficiency', 'Unfair Trade Practices', 'E-commerce Disputes', 'Banking Complaints', 'Insurance Claims', 'Medical Negligence'], courts: ['District Consumer Forum', 'State Consumer Commission', 'National Consumer Commission', 'High Court'], cases: '200+', successRate: '91%', isActive: true },
  ],
  aboutPage: {
    heroTitle: 'Two Decades of Legal Excellence',
    heroSubtitle: 'Founded on the principles of integrity, dedication, and client-focused representation, Advocate Law Chambers has been a trusted name in legal services since 2003.',
    advocateName: 'Adv. Arun Kumar',
    advocateTitle: 'Senior Advocate',
    education: 'LLB, Delhi University',
    location: 'New Delhi, India',
    bio: [
      'Advocate Arun Kumar is a distinguished legal professional with over two decades of experience in criminal defense, civil litigation, family law, and corporate legal matters. His career is marked by an unwavering commitment to justice and client success.',
      'After completing his law degree from the prestigious Delhi University, he was enrolled with the Bar Council of Delhi in 2003. His early years were spent learning under senior advocates at leading law firms, where he developed a strong foundation in litigation strategy and courtroom advocacy.',
      'In 2012, he established Advocate Law Chambers with a vision to provide accessible, high-quality legal services to individuals and businesses alike. The practice has since grown to handle cases across various courts, including the Supreme Court of India, High Courts, District Courts, and specialized tribunals.',
    ],
    certifications: [
      'Bar Council of Delhi - Enrollment No. D/1234/2003',
      'Supreme Court of India - AOR Designation',
      'Certified Mediator - Delhi High Court Mediation Centre',
      'Member - Delhi High Court Bar Association',
      'Member - Supreme Court Bar Association',
    ],
    timeline: [
      { year: '2003', title: 'Enrolled with Bar Council of Delhi', description: 'Began legal practice after completing LLB from Delhi University' },
      { year: '2008', title: 'Senior Associate at Leading Law Firm', description: 'Handled complex criminal and civil litigation cases' },
      { year: '2012', title: 'Established Independent Practice', description: 'Founded Advocate Law Chambers with focus on client success' },
      { year: '2018', title: 'Supreme Court Practice', description: 'Designated to practice before the Supreme Court of India' },
      { year: '2023', title: '20 Years of Excellence', description: 'Celebrating two decades of successful legal representation' },
    ],
    ethicsStatement: 'We believe that the practice of law is a sacred responsibility. Every client who walks through our doors receives our complete attention, honest counsel, and vigorous representation. We never compromise on ethics, and we treat every case with the gravity it deserves.',
  },
  knowledge: {
    articles: [
      { id: 1, title: 'Understanding Bail: A Complete Guide to Bail Provisions in India', excerpt: 'Learn about different types of bail, anticipatory bail, and the legal procedures involved in securing bail in criminal cases.', category: 'Criminal Law', date: '2024-01-15', readTime: '8 min read', featured: true },
      { id: 2, title: 'Property Registration Process: Step-by-Step Guide', excerpt: 'A comprehensive guide to property registration in India, including required documents, stamp duty, and common pitfalls to avoid.', category: 'Property Law', date: '2024-01-10', readTime: '6 min read', featured: true },
      { id: 3, title: 'Divorce Proceedings Under Hindu Marriage Act', excerpt: 'Understanding grounds for divorce, maintenance, custody, and the legal process for dissolving marriage under Hindu law.', category: 'Family Law', date: '2024-01-05', readTime: '10 min read', featured: false },
      { id: 4, title: 'Consumer Rights: Filing Complaints in Consumer Forum', excerpt: 'Know your rights as a consumer and learn how to file effective complaints against deficient services or defective products.', category: 'Consumer Law', date: '2023-12-28', readTime: '5 min read', featured: false },
      { id: 5, title: 'Starting a Company: Legal Requirements and Compliance', excerpt: 'Essential legal requirements for company registration, director responsibilities, and ongoing compliance obligations.', category: 'Corporate Law', date: '2023-12-20', readTime: '7 min read', featured: false },
    ],
    faqs: [
      { question: 'How do I know if I have a valid legal case?', answer: 'Determining the validity of a legal case requires examining the facts against applicable laws. We recommend booking a consultation with your case details for a professional assessment.' },
      { question: 'What is the difference between civil and criminal cases?', answer: 'Civil cases involve disputes between individuals or organizations (property, contracts, family matters), while criminal cases involve prosecution by the state for violations of criminal law.' },
      { question: 'How long do legal proceedings typically take?', answer: 'The duration varies significantly based on case complexity, court backlog, and type of matter. Simple matters may resolve in months, while complex litigation can take years.' },
      { question: 'What documents should I keep ready for legal consultation?', answer: 'Gather all relevant documents including agreements, correspondence, ID proofs, previous legal orders if any, and a chronological summary of events.' },
      { question: 'Can I change my lawyer during an ongoing case?', answer: "Yes, you have the right to change your legal counsel at any stage. However, it's important to ensure proper handover of case files and documents." },
    ],
  },
  contact: {
    address: '123 Legal Tower, 4th Floor, Civil Lines, Near District Court, New Delhi - 110001',
    phone: '+91 98765 43210',
    officePhone: '+91 11 2345 6789',
    email: 'contact@advocatelawchambers.com',
    inquiryEmail: 'inquiries@advocatelawchambers.com',
    hours: 'Monday - Friday: 10:00 AM - 7:00 PM\nSaturday: 10:00 AM - 4:00 PM\nSunday: By Appointment Only',
    mapEmbed: 'https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3501.534682695469!2d77.22479931508096!3d28.637988982416287!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x390cfd37b741d057%3A0xcdee88e47393c3f1!2sConnaught%20Place%2C%20New%20Delhi%2C%20Delhi!5e0!3m2!1sen!2sin!4v1647856385542!5m2!1sen!2sin',
  },
};

// ─── Context ──────────────────────────────────────────
interface ContentContextType {
  content: SiteContent;
  updateHero: (data: Partial<HeroContent>) => void;
  updateAboutSection: (data: Partial<AboutSectionContent>) => void;
  updateCTA: (data: Partial<CTAContent>) => void;
  updateTestimonials: (data: TestimonialItem[]) => void;
  updatePracticeAreas: (data: PracticeAreaItem[]) => void;
  updateAboutPage: (data: Partial<AboutPageContent>) => void;
  updateKnowledge: (data: Partial<KnowledgeContent>) => void;
  updateContact: (data: Partial<ContactContent>) => void;
  resetToDefaults: () => void;
}

const ContentContext = createContext<ContentContextType | undefined>(undefined);

const STORAGE_KEY = 'advocate_site_content';

export const ContentProvider = ({ children }: { children: ReactNode }) => {
  const [content, setContent] = useState<SiteContent>(() => {
    try {
      const stored = localStorage.getItem(STORAGE_KEY);
      if (stored) {
        return { ...defaultContent, ...JSON.parse(stored) };
      }
    } catch {
      // ignore
    }
    return defaultContent;
  });

  useEffect(() => {
    localStorage.setItem(STORAGE_KEY, JSON.stringify(content));
  }, [content]);

  const updateHero = (data: Partial<HeroContent>) =>
    setContent(c => ({ ...c, hero: { ...c.hero, ...data } }));

  const updateAboutSection = (data: Partial<AboutSectionContent>) =>
    setContent(c => ({ ...c, aboutSection: { ...c.aboutSection, ...data } }));

  const updateCTA = (data: Partial<CTAContent>) =>
    setContent(c => ({ ...c, cta: { ...c.cta, ...data } }));

  const updateTestimonials = (data: TestimonialItem[]) =>
    setContent(c => ({ ...c, testimonials: data }));

  const updatePracticeAreas = (data: PracticeAreaItem[]) =>
    setContent(c => ({ ...c, practiceAreas: data }));

  const updateAboutPage = (data: Partial<AboutPageContent>) =>
    setContent(c => ({ ...c, aboutPage: { ...c.aboutPage, ...data } }));

  const updateKnowledge = (data: Partial<KnowledgeContent>) =>
    setContent(c => ({ ...c, knowledge: { ...c.knowledge, ...data } }));

  const updateContact = (data: Partial<ContactContent>) =>
    setContent(c => ({ ...c, contact: { ...c.contact, ...data } }));

  const resetToDefaults = () => {
    setContent(defaultContent);
    localStorage.removeItem(STORAGE_KEY);
  };

  return (
    <ContentContext.Provider value={{
      content,
      updateHero,
      updateAboutSection,
      updateCTA,
      updateTestimonials,
      updatePracticeAreas,
      updateAboutPage,
      updateKnowledge,
      updateContact,
      resetToDefaults,
    }}>
      {children}
    </ContentContext.Provider>
  );
};

export const useContent = () => {
  const ctx = useContext(ContentContext);
  if (!ctx) throw new Error('useContent must be used within ContentProvider');
  return ctx;
};
